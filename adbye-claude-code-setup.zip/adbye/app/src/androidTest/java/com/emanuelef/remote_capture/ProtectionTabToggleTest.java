package com.emanuelef.remote_capture;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isChecked;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

// STARTER STUB — this is the CI evidence phase-1-protection-tab-ui's
// Testing Gate calls "Espresso UI test". View IDs below are guesses;
// replace with your real ones from ProtectionFragment's layout. Runs as
// part of `./gradlew connectedCheck`, wired into
// .github/workflows/phase-gate-ci.yml.
@RunWith(AndroidJUnit4.class)
public class ProtectionTabToggleTest {

    @Rule
    public ActivityScenarioRule<FirewallActivity> activityRule =
            new ActivityScenarioRule<>(FirewallActivity.class);

    @Test
    public void adBlockToggle_flipsPrefAndRegeneratesRulesWithoutServiceRestart() {
        onView(withId(R.id.tab_protection)).perform(click());

        // TODO: read CaptureService's current start timestamp/PID here,
        // before the toggle, so the "no restart" half of constraint #7
        // can actually be asserted below instead of just asserted in a
        // comment.

        onView(withId(R.id.switch_protect_adblock)).perform(click());
        onView(withId(R.id.switch_protect_adblock)).check(matches(isChecked()));

        boolean prefValue = Prefs.isAdBlockEnabled(
                InstrumentationRegistry.getInstrumentation().getTargetContext());
        Assert.assertTrue("pref_protect_adblock should be true after toggle", prefValue);

        // TODO: assert filesDir/adblock_rules.txt mtime changed (rules
        // regenerated) AND CaptureService's PID/start-timestamp from above
        // is unchanged (no restart). Both halves are required for this
        // test to actually be evidence for constraint #7, not just proof
        // the checkbox visually ticks.
    }
}
