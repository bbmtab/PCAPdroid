package com.emanuelef.remote_capture;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

// STARTER STUB — CI evidence for phase-3-sni-early-drop's "Network test".
// Assumes the VPN + a blocklist containing the domain below is already
// running by the time this test executes (wire that setup into a @Before
// or an instrumented test app config if it isn't automatic yet).
//
// Deliberately uses a raw HttpURLConnection instead of driving a browser:
// far less flaky in CI, and it isolates exactly the layer this phase
// claims to affect (connection-level), matching the plan's own
// distinction between a connection error (right layer) and a certificate
// error (wrong layer, meaning the drop isn't happening at SNI time).
@RunWith(AndroidJUnit4.class)
public class SniEarlyDropTest {

    private static final String BLOCKLISTED_DOMAIN = "https://google-analytics.com/";

    @Test
    public void blockedDomain_connectionResetAtSniLayer_notCertError() {
        IOException thrown = assertThrows(IOException.class, () -> {
            HttpURLConnection conn = (HttpURLConnection) new URL(BLOCKLISTED_DOMAIN).openConnection();
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.connect();
            conn.getResponseCode();
        });

        // TODO: tighten this to the exact exception your splice
        // implementation actually throws (e.g. a specific ConnectException
        // message) so a real DNS blip or unrelated flake can't
        // false-positive this test into "passing".
        boolean isCertError = thrown instanceof javax.net.ssl.SSLHandshakeException;
        assertTrue(
                "expected a connection-level failure, not a TLS/cert failure "
                        + "(a cert error means the drop is happening too late): " + thrown,
                !isCertError);
    }

    @Test
    public void filterHttpsFalseApp_isNotDroppedForSameDomain() {
        // TODO: needs the test process to run under (or spoof) a UID that
        // has filterHttps=false set via the Phase-1 app-management prefs,
        // then assert the same URL above connects successfully. Left as a
        // stub because how you spoof/select the UID depends on how
        // app_management_tab_layout_blueprint.md ends up storing the
        // per-UID flag — fill in once that phase's storage shape exists.
    }
}
