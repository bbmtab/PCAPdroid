# ADBye — PCAPdroid-based AdGuard-parity content filter

Full roadmap + testing gates: `PLAN.md` at repo root — read it before starting
any phase. This file only holds what must load every session.

## Non-negotiable constraints (full text in PLAN.md)
1. Branding: app label "ADBye", `ic_adbye_shield.xml`.
2. Resource Protection allowlist is hardcoded, unbypassable even in Strict mode.
3. **Release-tested, not debug-only.** "Green in Android Studio" is not done.
   Every phase must build as a signed **Release APK with R8/ProGuard on**.
   A debug-only pass is not evidence of anything for this project.
4. Every UI toggle needs an Espresso E2E test proving the click changes real
   network behavior — a passing unit test alone does not satisfy this.
5. **No mocking PCAPdroid core or MitmService IPC for final validation** of
   Phase 3/4. A mock is fine for your own dev iteration; it does not count
   toward marking the phase done.
6. `pref_global_https_filtering` defaults `false`, gated behind CA install +
   `MitmAddon.needsSetup()`.
7. Toggling a Protection-tab switch hot-reloads the engine — no
   `CaptureService` restart.
8. Final gate is a CI emulator pipeline (GitHub Actions + UIAutomator/
   Espresso): real APK install, real VPN permission dialog, real toggles,
   real HTTP requests. Passing local unit tests but failing that pipeline
   means the work is rejected.

## Phase discipline
Work happens in 5 gated phases tracked in `.claude/phase-state.json` →
`current_phase`. Load `.claude/skills/phase-<n>-*/SKILL.md` for the phase
you're currently on before writing code. Don't touch a later phase's files
"while you're in there" — flag the dependency to the user and ask instead
of quietly doing it.

## What's mechanically enforced vs. what you must self-report
A `Stop` hook (`.claude/hooks/verify-phase-gate.sh`) blocks you from ending
a turn if the real **release** build fails, a new file isn't referenced
anywhere outside itself, or the current phase's code-level markers (exact
class/method/pref names — see that phase's skill) are missing.

The hook cannot drive an emulator, click a VPN permission dialog, watch a
YouTube video, or run the CI pipeline. Constraints 3 (actual APK artifact),
4 (Espresso E2E), 8 (CI pipeline), and every "Manual" / "Network" / "E2E"
line in a phase's Testing Gate are on you to actually run and report —
state what you ran, against what target, and the actual result you saw.
"Should work" is not a result, and the hook passing silently is not
evidence that these were done.
