---
name: phase-4-https-content-filtering
description: Scope and testing gate for Phase 4 (HTTPS content filtering, Layer 3) of the ADBye roadmap — IPC contract with the real PCAPdroid-mitm addon for AdGuard-rule/cosmetic/scriptlet filtering. Load when current_phase is 4, before touching MitmAPI.MitmConfig or the addon IPC bundle.
---

# Phase 4 — HTTPS Content Filtering (Layer 3 via MITM Addon)

Reference: `blocking_plan.md` (Layer 3 / IPC contract).
Depends on Phases 0–3. Split across two repos: this repo owns the data
path (merged rules file + IPC), the separate `PCAPdroid-mitm` addon owns
the AdGuard-syntax parser, cosmetic CSS injection, and scriptlets.

**Constraint #5 applies directly here: mocking the PCAPdroid core or the
MitmService IPC is not acceptable for final validation.** Use a mock during
your own development if that helps you move faster, but the exit criteria
below require the real addon, not a stand-in for it.

## Build
- `MitmAPI.MitmConfig`: add `rulesPath` + `cosmeticLibraryPath` fields.
- `FilterListManager` passes the absolute path of `adblock_rules.txt`
  through the real IPC bundle.
- Cross-repo: AdGuard-syntax + CSS injection + scriptlet parsing lands in
  `PCAPdroid-mitm` (tracked there, not here — this repo only needs the IPC
  contract honored, not the parser implementation).
- `pref_global_https_filtering` toggle gated behind
  `MitmAddon.needsSetup()` (CA install required), defaults `false`. If you
  add a debug bypass for this gate during development, it must not be
  reachable in the release build — remove or fence it out before this
  phase is marked done.

## CI evidence
This is the one phase where `.github/workflows/phase-gate-ci.yml` needs a
real extension, not just another test file: the `instrumented-tests` job
currently only builds/installs this repo. A working E2E CI run for this
phase needs an extra step that also builds (or downloads a release of) the
`PCAPdroid-mitm` addon APK and installs it on the same AVD before
`connectedCheck` runs — that step doesn't exist yet. Add it as part of
this phase's own work; don't mark Phase 4 done with an E2E test that only
ever ran manually on your own device.

## Testing Gate
- **E2E:** install both ADBye and the real (not mocked) modified MITM
  addon, enable HTTPS filtering.
- **Browser test:** visit `adblock-tester.com` or
  `d3ward.github.io/toolz/adblock`, confirm cosmetic rules (empty ad
  containers hidden) and scriptlets actually execute in the page — check
  the rendered DOM/behavior, not just that the request didn't error out.

## Exit criteria
1. `MitmAPI.MitmConfig` has both new fields.
2. The IPC send site actually includes the populated `rulesPath` (grep the
   call site, not just the field declaration).
3. `pref_global_https_filtering` defaults `false` in code, gated behind
   `MitmAddon.needsSetup()`, with no reachable bypass in the release build.
4. E2E + browser test above run against the real addon, with specifics
   reported — which cosmetic rules fired, which scriptlets ran.
5. Real release build succeeds.

This is the last local phase. Constraint #8 (CI emulator pipeline) is the
actual final gate for the whole roadmap — flag to the user whether
`.github/workflows/` for this already exists, since nothing in this skill
set builds that pipeline for you.
