---
name: phase-gate
description: How ADBye's 5-phase gating works — where the current phase is tracked, how to advance, and the split between what the Stop hook checks mechanically versus what must be manually run and reported. Load at the start of any session on this repo, before loading a phase-specific skill.
---

# Phase gate

Source of truth: `.claude/phase-state.json`.

## Every session, in order
1. Read `current_phase` from `.claude/phase-state.json`.
2. Load `.claude/skills/<phases[current_phase]>/SKILL.md`.
3. Stay inside that phase's scope. A later phase's files are off-limits
   even for a "quick peek" — flag the dependency to the user instead of
   quietly doing the work.

## Two different kinds of "done" — don't conflate them
- **Mechanically checked**, every turn, by the `Stop` hook: real release
  build succeeds, new files are referenced somewhere outside themselves,
  the phase-specific class/method/pref names from that phase's skill
  exist in the source.
- **Must be run and reported by you, in words, before you claim the phase
  done**: every "Manual" / "Network" / "Integration" / "E2E" / "Browser"
  line in that phase's Testing Gate, plus constraint #3 (an actual signed
  `.apk` artifact), #4 (Espresso E2E), #5 (no mock on final validation),
  and #8 (the CI pipeline). The hook cannot open an emulator or tap a VPN
  permission dialog — it will pass cleanly while all of that is still
  unverified. That's not the hook being wrong; it's checking the subset a
  shell script can check. The rest is on you, every time.

## Advancing
1. State which mechanical criteria you expect to pass and which manual
   ones you ran, with actual results — not "should work."
2. Stop your turn. The hook re-checks the mechanical subset and blocks
   with a specific reason if something's missing.
3. Only after a clean hook pass **and** your own manual results are
   reported in the conversation, bump `current_phase` in
   `.claude/phase-state.json` yourself. Never bump it just to silence the
   hook or because a later task is more interesting.
