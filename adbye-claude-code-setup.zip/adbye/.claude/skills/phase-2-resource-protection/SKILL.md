---
name: phase-2-resource-protection
description: Scope and testing gate for Phase 2 (Resource Protection / anti-crash layer) of the ADBye roadmap — hardcoded allowlist for Google/CDN/Play/FCM traffic so it's never blocked, even in Strict mode. Load when current_phase is 2, before touching BypassManager.
---

# Phase 2 — Resource Protection ("Anti-Crash" Layer)

Reference: `filter_list_plan.md` § Resource Protection.
Depends on Phase 0 (blocklist exists) + Phase 1 (Strict-mode toggle exists
to test against).

## Build
- `BypassManager.java`, singleton.
- Hardcoded UID allowlist: `com.android.vending`, `com.google.android.gms`,
  `com.google.android.gsf`, `com.google.android.ims`.
- Hardcoded domain/SNI allowlist: `googlevideo.com`, `mtalk.google.com`,
  plus CDN domains — enumerate the actual set you ship in `BypassManager`
  and mirror it into `filter_list_plan.md`; don't let the real list only
  exist in code where nobody else can review it.
- FCM port bypass: 5228, 5229, 5230.
- Dynamic flow threshold: splice to raw TCP once payload > 5MB or
  `Content-Length` > 20MB.
- All of the above wired into the **live** connection-state decision path
  — a `BypassManager` that nothing calls is a Phase 2 failure by itself,
  independent of whether the lists inside it are correct.

## CI evidence vs. real-device-only
Be honest about which of these three actually run in
`.github/workflows/phase-gate-ci.yml` vs. which need a physical device:
- **Download (memory-flat) and Video (YouTube plays)** are realistically
  manual/real-device only — CI emulators don't reliably reproduce sustained
  large transfers or a real YouTube session. Don't fake a CI job for these;
  say so and report them as manual results instead.
- **Push** and the underlying **domain-allowlist bypass** ARE CI-automatable:
  an instrumented test can hit `googlevideo.com` directly (same technique
  as `SniEarlyDropTest`, but asserting success instead of failure) with
  Strict mode force-enabled, and check Logcat for the `BypassManager`
  "Bypassed" line via `adb logcat -d | grep`. Add that test alongside
  `SniEarlyDropTest` once Phase 2 lands; there isn't a stub for it yet.

## Testing Gate — all manual, all on a real device
- **Video:** open YouTube, video starts immediately in 1080p, Logcat shows
  `BypassManager` logging `"Bypassed googlevideo.com"`.
- **Push:** trigger a real WhatsApp or Firebase test push, confirm instant
  delivery (port 5228 bypass working).
- **Download:** pull a ~2GB app from the Play Store, VPN memory usage
  stays flat throughout — proves the dynamic flow bypass is engaging
  rather than buffering the whole transfer through the filter path.

## Exit criteria
1. `BypassManager.java` exists, single instance.
2. UID list, domain list, and FCM ports are each referenced from the real
   connection-state path (grep for call sites outside the file itself).
3. All three Testing Gate items run on a real device and reported with
   what you actually observed — Logcat lines, memory numbers, delivery
   timing — not "should be fine."
4. Real release build succeeds.

Don't start Phase 3 until all four hold.
