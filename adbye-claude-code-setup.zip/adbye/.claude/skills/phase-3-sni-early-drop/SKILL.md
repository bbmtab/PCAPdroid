---
name: phase-3-sni-early-drop
description: Scope and testing gate for Phase 3 (SNI early-drop, Layer 2) of the ADBye roadmap — drop matching flows at TLS ClientHello, before any CA/MITM is involved. Load when current_phase is 3, before touching the ClientHello/SNI parsing path.
---

# Phase 3 — SNI Early-Drop (Layer 2)

Reference: `blocking_plan.md` (Layer 2 section).
Depends on Phase 0 (blocklist) and Phase 1's per-UID `filterHttps` setting
(check `app_management_tab_layout_blueprint.md` — if that hasn't actually
landed yet, this is a real blocking dependency; say so rather than
stubbing the check).

## Build
- Hook into PCAPdroid's existing TLS ClientHello parser — locate it first,
  confirm it before rewriting anything.
- Match extracted SNI against the Phase-0 merged blocklist, in that same
  code path (not a separate offline check).
- On match: close/drop the socket immediately.
- Respect per-UID `filterHttps=false` — exempt that app from the drop.

## CI evidence
This phase's Network test is the most directly CI-automatable item in the
whole roadmap — a starter stub already exists at
`app/src/androidTest/java/com/emanuelef/remote_capture/SniEarlyDropTest.java`,
wired into `.github/workflows/phase-gate-ci.yml`. It uses a raw
`HttpURLConnection` instead of a real browser specifically so it isn't
flaky in CI — but its `filterHttpsFalseApp_isNotDroppedForSameDomain` test
is still an empty `TODO` because it depends on how Phase 1's per-UID
storage ends up shaped. Fill that in as part of this phase, don't leave it
stubbed when you mark the phase done.

## Testing Gate
- **Network test:** on a device **without the MITM CA installed**, visit a
  known tracker domain (e.g. `google-analytics.com`).
- **Verification:** the browser must show `ERR_CONNECTION_CLOSED` or
  `ERR_CONNECTION_RESET` immediately. This specifically proves the drop
  happened at the SNI/handshake layer, not a later TLS failure. A
  certificate error instead of a connection error means the drop is
  happening in the wrong place — that's a fail, not a pass with a
  different symptom.

## Exit criteria
1. SNI-read-and-match happens in the real capture path, not a standalone
   test harness.
2. Network test above run with no CA installed; exact error shown
   (`ERR_CONNECTION_CLOSED` / `RESET`) reported.
3. A `filterHttps=false` app confirmed NOT dropped for the same domain —
   separate manual test, report which app and domain you used.
4. Real release build succeeds.

Don't start Phase 4 until all four hold.
