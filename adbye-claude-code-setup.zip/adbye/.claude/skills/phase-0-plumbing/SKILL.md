---
name: phase-0-plumbing
description: Scope and testing gate for Phase 0 (Plumbing) of the ADBye roadmap — FilterListManager, FilterListRepository, and merging filter sources into adblock_rules.txt. Load when .claude/phase-state.json current_phase is 0, before touching filter fetching/parsing/merge code.
---

# Phase 0 — Plumbing (Data & Engine Sync)

Reference: `filter_list_plan.md` (this phase may be the one that writes it,
if it doesn't exist yet).

## Build
- `FilterListManager.java` — URL fetcher + merge logic.
- `FilterListRepository` — Room DB or JSON-backed SharedPreferences (pick
  one, record the decision in `filter_list_plan.md`; don't leave it only
  implicit in code).
- `addList()` expanded to accept user-added custom filter URLs, not just
  the shipped defaults.

## Testing Gate (run these yourself — the Stop hook only checks wiring)
- **Unit test:** mock 3 filter URLs, verify `FilterListManager.merge()`
  combines them into `filesDir/adblock_rules.txt` with no duplicates.
- **Manual check:** inspect the generated `.txt` via Android Studio Device
  Explorer, confirm standard AdGuard syntax is preserved, not mangled by
  the merge step.

## Exit criteria
1. `FilterListManager.java` exists and is referenced from `CoreService`.
2. `FilterListRepository` exists and `FilterListManager` actually reads/
   writes through it (not an untouched scaffold sitting next to it).
3. `addList()` takes an arbitrary URL parameter.
4. Unit test above passes.
5. Manual `.txt` inspection done and reported — paste what you actually
   saw, not "looks fine."
6. Real **release** build succeeds (`./gradlew assembleRelease`).

Don't start Phase 1 until all six hold and you've explicitly reported 4–5.
