---
name: phase-1-protection-tab-ui
description: Scope and testing gate for Phase 1 (Protection tab UI) of the ADBye roadmap — 4th FirewallActivity tab with the 6 master toggles (Ad/Tracking/Annoyance/DNS/Firewall/Security) and hot-reload wiring. Load when current_phase is 1, before touching FirewallActivity, ProtectionFragment, or Prefs.java.
---

# Phase 1 — GUI: Protection Tab

Reference: `firewall_blocking_tab.md`, `protection_layout.md`.
Depends on Phase 0 (needs real filter data to populate counts).

## Build
- 4th tab, `POS_PROTECTION`, on `FirewallActivity`.
- `ProtectionFragment` — exactly 6 master toggles: **Ad, Tracking,
  Annoyance, DNS, Firewall, Security**. Not more, not fewer, not renamed.
- Prefs keys following the `pref_protect_<category>` pattern (e.g.
  `pref_protect_adblock`) — one per toggle, in `Prefs.java`.
- Every toggle calls `FilterListManager.mergeEnabledLists()` (or the real
  equivalent you land on — if the name differs from `PLAN.md`, update
  `PLAN.md` to match; don't let it silently drift) on change.
- Branding: first new screen — use `ic_adbye_shield.xml`, confirm
  `app_name` reads "ADBye".

## Testing Gate
- **Espresso UI test:** click each toggle, verify the matching
  `Prefs.java` value updates.
- **Integration test:** with the VPN running, toggle "Ad blocking" off,
  verify `adblock_rules.txt` regenerates instantly (Ad lists excluded)
  **without** `CaptureService` restarting. This is constraint #7
  (hot-reload) — a toggle that only flips a pref and never touches the
  live file/engine fails this phase regardless of how the UI looks.

## CI evidence
The Espresso test below is not optional local-only tooling — it's what
runs in `.github/workflows/phase-gate-ci.yml`'s `instrumented-tests` job,
which is constraint #8's actual enforcement. A starter stub exists at
`app/src/androidTest/java/com/emanuelef/remote_capture/ProtectionTabToggleTest.java`
— it has real `TODO`s (asserting the file actually regenerates, asserting
`CaptureService` didn't restart) that must be filled in, not left as
comments, before this phase is done. Passing locally in Android Studio is
not the same as passing in that GitHub Actions job — confirm the workflow
run itself, not just your own machine.

## Exit criteria
1. `POS_PROTECTION` tab registered, points to `ProtectionFragment`.
2. All 6 named toggles present, each with its own pref key, each key
   actually read somewhere (not just written).
3. Espresso test above passes.
4. Integration test above passes — report what you observed in
   `adblock_rules.txt` before/after, and confirm no service restart.
5. Real release build succeeds.

Don't start Phase 2 until all five hold.
